
public class busStops {
		
		public int stop_id;
		//public int stop_code;
		public String stop_name;
		//public String stop_desc;
		//public String stop_lat; //double
		//public String stop_lon;//double
		//public String zone_id;
		//public String stop_url;
		//public int location_type;
		//public String parent_station;
		
		busStops(int stop_id, String stop_name)
		{
			this.stop_id = stop_id;
			//this.stop_code = stop_code;
			this.stop_name = stop_name;
			//this.stop_desc = stop_desc;
			//this.stop_lat = stop_lat;
			//this.stop_lon = stop_lon;
			//this.zone_id = zone_id;
			//this.stop_url = stop_url;
			//this.location_type = location_type;
			//this.parent_station = parent_station;
			
		}

	}


